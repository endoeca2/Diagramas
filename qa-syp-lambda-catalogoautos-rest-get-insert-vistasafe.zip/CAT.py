import pandas as pd
from TDV import TDV
from AWS import AWS
import os
from pprint import pprint
from datetime import datetime

class Catalogo:
    def __init__(self, cat:str, input_file:pd.DataFrame, tdv:TDV) -> None:
        self.input_file = input_file
        self.tdv = tdv
        if cat == 'autos':
            self.gen_autos()
        if cat == 'modelos':
            self.gen_modelos()
        if cat == 'tipo_veh':
            self.gen_tipos_veh()
        if cat == 'marcas':
            self.gen_marcas()
        self.file_cat_apartado = 'vista-safe/CAT_APARTADOS.csv'

    def gen_autos(self):
        self.sbg            = ['VARCHAR',None]
        self.descripcion    = ['VARCHAR',None]
        self.tipo           = ['VARCHAR',None]
        self.amis           = ['VARCHAR',None]
        self.pasajeros      = ['VARCHAR',None]
        self.cilindros      = ['VARCHAR',None]
        self.toneladas      = ['VARCHAR',None]
        self.gpodm          = ['VARCHAR',None]
        self.gport          = ['VARCHAR',None]
        self.gporc          = ['VARCHAR',None]
        self.carroceria     = ['VARCHAR',None]
        self.clase          = ['VARCHAR',None]
        self.gpotar         = ['VARCHAR',None]
        self.orig           = ['VARCHAR',None]
        self.transmision    = ['VARCHAR',None]
        self.puertas        = ['VARCHAR',None]
        self.fecharegistro  = ['VARCHAR',None]
        self.subramo        = ['VARCHAR',None]
        self.TipoVehiculoDsc= ['VARCHAR',None]

    def gen_modelos(self):
        self.sbg             = ['VARCHAR', None]
        self.modelo          = ['VARCHAR', None]
        self.fecharegistro   = ['VARCHAR', None]
        self.valornuevo      = ['VARCHAR', None]
        self.valorcomercial  = ['VARCHAR', None]
        self.variacion       = ['DOUBLE', None]
        self.subramo         = ['VARCHAR', None]
        self.grupo           = ['VARCHAR', None]
        self.estados         = ['VARCHAR', None]

    def gen_tipos_veh(self):
        self.TipoVehiculoDsc = ['VARCHAR', None]
        self.cveMarca        = ['VARCHAR', None]

    def gen_marcas(self):
        self.GpoMarcas = ['VARCHAR', None]
        self.Descripcion = ['VARCHAR', None]
        self.CveRamo =  ['VARCHAR', None]
        self.CveSubRamo =  ['VARCHAR', None]
        self.CveMarca =   ['VARCHAR', None]
        
    def insertar_autos(self, df_vista):
        aws_conn = AWS()
        s3_bucket_name = os.getenv("s3_bucket_name")
        s3_key_inserts = 'autos_inserts.txt'
        s3_key_inserts_fails = 'autos_inserts_fails.txt'

        # Cargar y procesar archivo de CAT_APARTADOS
        cat_apartados = aws_conn.traer_dataframe_desde_s3(self.file_cat_apartado, s3_bucket_name)

        # Crear la llave CODCAT_CODAPARTADO_CODVEHICULO en el input_file
        self.input_file['CODCAT_CODAPARTADO_CODVEHICULO'] = (
            self.input_file['CODCAT'].astype(str) + '|' + 
            self.input_file['CODAPARTADO'].astype(str) + '|' + 
            self.input_file['CODVEHICULO'].astype(str)
        )

        # Crear la misma llave en df_vista concatenando CODCAT, CODAPARTADO y CODVEHICULO
        df_vista['CODCAT_CODAPARTADO_CODVEHICULO'] = (
            df_vista['CODCAT'].astype(str) + '|' + 
            df_vista['CODAPARTADO'].astype(str) + '|' + 
            df_vista['CODVEHICULO'].astype(str)
        )

        # Configurar el índice en df_vista basado en la llave concatenada
        df_vista = df_vista.set_index('CODCAT_CODAPARTADO_CODVEHICULO')

        # Registro de fallos y ejecuciones exitosas
        insert_scripts = []
        fails = []

        # Iterar sobre cada fila del input_file y verificar si la llave está en df_vista
        for index, row in self.input_file.iterrows():
            llave = row['CODCAT_CODAPARTADO_CODVEHICULO']

            # Verificar si la llave está en df_vista
            if llave in df_vista.index:
                # Obtener valores de SBG y otros campos necesarios
                tipo_vehiculo_dsc = str(row['CODMARCA_CODMODELO'][row['CODMARCA_CODMODELO'].rfind('|')+1:])
                cvemarca = str(row['SBG'])[:2]
                
                # Query para obtener TipoVehiculoId
                query_tipo_vehiculo = f"""
                    SELECT TOP 1 TipovehiculoId 
                    FROM /shared/CONEXIONES/SAFE_SARAWEB/Saraweb/dbo/TipoVehiculo 
                    WHERE TipoVehiculoDsc = '{tipo_vehiculo_dsc}' 
                    AND cvemarca = '{cvemarca}'
                """
                response = self.tdv.execute_select(query_tipo_vehiculo)
                tipo_vehiculo_id = response["result"][0]["TipovehiculoId"] if response and response.get("result") else 0

                formatted_date = datetime.strptime(self.input_file.at[index, 'FECHA'], '%Y-%m-%d').strftime('%Y-%m-%d 00:00:00')
                # Construir valores para el `INSERT`
                values = (
                    f"'{self.input_file.at[index, 'SBG']}'",
                    f"'{row['DESCRIPCION']}'",
                    "'01'",  # Tipo (default)
                    f"'{row['AMIS']}'",
                    f"'{row['PAS']}'",
                    f"'{row['CIL']}'",
                    f"'{row['TON']}'",
                    f"'{row['GPODM']}'",
                    f"'{row['GPORT']}'",
                    f"'{row['GPORC']}'",
                    f"'{row['CARR']}'",
                    f"'{row['CLA']}'",
                    f"'{row['GPOTAR']}'",
                    f"'{row['ORIG']}'",
                    f"'{row['TRANSMISION']}'",
                    f"'{row['PTA']}'",
                    f"'{formatted_date}'",
                    f"'{cat_apartados.query('CODAPARTADO == ' + str(row['CODAPARTADO']))['SUBRAMO'].iloc[0]}'",
                    f"{tipo_vehiculo_id}"
                )
                sql_query = f"""
                    INSERT INTO /shared/CONEXIONES/SAFE_SARAWEB/Saraweb/dbo/catentidadautos_carga (
                        sbg, descripcion, tipo, amis, pasajeros, cilindros, toneladas, gpodm, 
                        gport, gporc, carroceria, clase, gpotar, orig, transmision, puertas, 
                        fecharegistro, subramo, TipoVehiculoId
                    )
                    VALUES ({','.join(values)});
                """

                # Ejecutar el `INSERT` de manera individual
                result = self.tdv.execute_insert(sql_query)
                if result:
                    insert_scripts.append(sql_query)
                else:
                    fails.append(sql_query)
            else:
                print(f"Registro {index} con llave {llave} no encontrado en df_vista. Se omite la inserción.")

        # Guardar resultados exitosos
        if insert_scripts:
            df_inserts = aws_conn.traer_dataframe_desde_s3(s3_key_inserts, s3_bucket_name)
            new_inserts = pd.DataFrame({"script": insert_scripts})
            df_inserts = pd.concat([df_inserts, new_inserts], ignore_index=True) if df_inserts is not None else new_inserts
            aws_conn.guardar_dataframe_vista_en_s3(df_inserts, s3_key_inserts, s3_bucket_name)

        # Guardar fallos
        if fails:
            print("Error ejecutando algunos INSERTs para autos.")
            df_fails = aws_conn.traer_dataframe_desde_s3(s3_key_inserts_fails, s3_bucket_name)
            new_fails = pd.DataFrame({"script": fails})
            df_fails = pd.concat([df_fails, new_fails], ignore_index=True) if df_fails is not None else new_fails
            aws_conn.guardar_dataframe_vista_en_s3(df_fails, s3_key_inserts_fails, s3_bucket_name)



    def insertar_modelos(self, df_vista):
        aws_conn = AWS()
        s3_bucket_name = os.getenv("s3_bucket_name")
        s3_key_inserts = 'modelos_inserts.txt'
        s3_key_inserts_fails = 'modelos_inserts_fails.txt'

        # Cargar y procesar archivo de CAT_APARTADOS
        cat_apartados = aws_conn.traer_dataframe_desde_s3(self.file_cat_apartado, s3_bucket_name)
        cat_apartados = cat_apartados.set_index('CODAPARTADO')

        # Unir input_file con CAT_APARTADOS
        input_file = self.input_file.join(cat_apartados, on='CODAPARTADO', how='inner')

        # Crear la llave CODCAT_CODAPARTADO_CODVEHICULO en el input_file
        input_file['CODCAT_CODAPARTADO_CODVEHICULO'] = (
            input_file['CODCAT'].astype(str) + '|' +
            input_file['CODAPARTADO'].astype(str) + '|' +
            input_file['CODVEHICULO'].astype(str)
        )

        # Crear la misma llave en df_vista concatenando CODCAT, CODAPARTADO y CODVEHICULO
        df_vista['CODCAT_CODAPARTADO_CODVEHICULO'] = (
            df_vista['CODCAT'].astype(str) + '|' +
            df_vista['CODAPARTADO'].astype(str) + '|' +
            df_vista['CODVEHICULO'].astype(str)
        )

        # Configurar el índice en df_vista basado en la llave concatenada
        df_vista = df_vista.set_index('CODCAT_CODAPARTADO_CODVEHICULO')

        # Registro de fallos y ejecuciones exitosas
        insert_scripts = []
        fails = []

        for index, row in input_file.iterrows():
            llave = row['CODCAT_CODAPARTADO_CODVEHICULO']

            # Verificar si la llave está en df_vista
            if llave in df_vista.index:
                # Obtener valores de SBG y FECHA de df_vista
                input_file.at[index, 'SBG'] = df_vista.at[llave, 'SBG']
                input_file.at[index, 'FECHA'] = df_vista.at[llave, 'FECHA']

                # Formatear la fecha con hora en el formato requerido
                formatted_date = datetime.strptime(input_file.at[index, 'FECHA'], '%Y-%m-%d').strftime('%Y-%m-%d 00:00:00')

                # Construir valores para el `INSERT`
                values = (
                    f"'{input_file.at[index, 'SBG']}'",
                    f"'{row['ANOVEH']}'",
                    f"'{formatted_date}'",
                    f"{row['MTOVALORNUEVO']}",
                    f"{row['MTOVALORCOMERCIAL']}",
                    "0",  # Variación por defecto
                    f"'{row['SUBRAMO']}'",
                    "'03'",  # Grupo por defecto
                    "',1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,'"  # Estados en el formato correcto
                )
                sql_query = f"""
                INSERT INTO /shared/CONEXIONES/SAFE_SARAWEB/Saraweb/dbo/catmodelos_carga
                (sbg, modelo, fecharegistro, valornuevo, valorcomercial, variacion, subramo, grupo, estados)
                VALUES ({','.join(values)});
                """
                # Ejecutar el `INSERT` de manera individual
                result = self.tdv.execute_insert(sql_query)
                if result:
                    insert_scripts.append(sql_query)
                else:
                    fails.append(sql_query)

        # Guardar resultados exitosos
        if insert_scripts:
            df_inserts = aws_conn.traer_dataframe_desde_s3(s3_key_inserts, s3_bucket_name)
            new_inserts = pd.DataFrame({"script": insert_scripts})
            df_inserts = pd.concat([df_inserts, new_inserts], ignore_index=True) if df_inserts is not None else new_inserts
            aws_conn.guardar_dataframe_vista_en_s3(df_inserts, s3_key_inserts, s3_bucket_name)

        # Guardar fallos
        if fails:
            print("Error ejecutando algunos INSERTs para modelos.")
            df_fails = aws_conn.traer_dataframe_desde_s3(s3_key_inserts_fails, s3_bucket_name)
            new_fails = pd.DataFrame({"script": fails})
            df_fails = pd.concat([df_fails, new_fails], ignore_index=True) if df_fails is not None else new_fails
            aws_conn.guardar_dataframe_vista_en_s3(df_fails, s3_key_inserts_fails, s3_bucket_name)

        
    def insertar_tipos_vehiculos(self):
        aws_conn = AWS()
        s3_bucket_name = os.getenv("s3_bucket_name")
        s3_key_inserts = 'tipos_vehiculos_inserts.txt'
        s3_key_inserts_fails = 'tipos_vehiculos_inserts_fails.txt'

        input_file = self.input_file

        # Registro de fallos y ejecuciones exitosas
        insert_scripts = []
        fails = []

        for index, row in input_file.iterrows():
            # Query para obtener el siguiente TipoVehiculoId
            query_tipo_vehiculo_id = """
                SELECT MAX(TipoVehiculoId) + 1 AS NextTipoVehiculoId
                FROM /shared/CONEXIONES/SAFE_SARAWEB/Saraweb/dbo/TipoVehiculo
            """
            response = self.tdv.execute_select(query_tipo_vehiculo_id)
            tipo_vehiculo_id = response["result"][0]["NextTipoVehiculoId"] if response and response.get("result") else None

            if not tipo_vehiculo_id:
                print(f"Error obteniendo TipoVehiculoId para registro {index}.")
                fails.append({
                    "TipoVehiculoDsc": str(row['DESCMODELO']),
                    "cveMarca": str(row['CODMARCA_CORTA']),
                    "error": "No se pudo obtener TipoVehiculoId"
                })
                continue

            # Construir valores para el `INSERT`
            values = (
                f"{tipo_vehiculo_id}",
                f"'{str(row['DESCMODELO'])}'",
                f"'{str(row['CODMARCA_CORTA'])}'"
            )
            sql_query = f"""
            INSERT INTO /shared/CONEXIONES/SAFE_SARAWEB/Saraweb/dbo/TipoVehiculo_carga
            (TipoVehiculoId, TipoVehiculoDsc, cveMarca)
            VALUES ({','.join(values)});
            """

            # Ejecutar el `INSERT` de manera individual
            result = self.tdv.execute_insert(sql_query)
            if result:
                insert_scripts.append(sql_query)
            else:
                fails.append({
                    "TipoVehiculoDsc": str(row['DESCMODELO']),
                    "cveMarca": str(row['CODMARCA_CORTA']),
                    "error": "Error ejecutando el INSERT"
                })

        # Guardar resultados exitosos
        if insert_scripts:
            df_inserts = aws_conn.traer_dataframe_desde_s3(s3_key_inserts, s3_bucket_name)
            new_inserts = pd.DataFrame({"script": insert_scripts})
            df_inserts = pd.concat([df_inserts, new_inserts], ignore_index=True) if df_inserts is not None else new_inserts
            aws_conn.guardar_dataframe_vista_en_s3(df_inserts, s3_key_inserts, s3_bucket_name)

        # Guardar fallos
        if fails:
            print("Error ejecutando algunos INSERTs para tipos de vehículos.")
            df_fails = aws_conn.traer_dataframe_desde_s3(s3_key_inserts_fails, s3_bucket_name)
            new_fails = pd.DataFrame(fails)
            df_fails = pd.concat([df_fails, new_fails], ignore_index=True) if df_fails is not None else new_fails
            aws_conn.guardar_dataframe_vista_en_s3(df_fails, s3_key_inserts_fails, s3_bucket_name)


    def insertar_marcas(self):
        aws_conn = AWS()
        s3_bucket_name = os.getenv("s3_bucket_name")
        s3_key_inserts = 'marcas_inserts.txt'
        s3_key_inserts_fails = 'marcas_inserts_fails.txt'

        # Cargar y procesar archivo de CAT_APARTADOS
        cat_apartados = aws_conn.traer_dataframe_desde_s3(self.file_cat_apartado, s3_bucket_name)
        input_file = self.input_file

        # Registro de fallos y ejecuciones exitosas
        insert_scripts_catMarcas = []
        insert_scripts_tmarca_especial = []
        fails = []

        # Insertar en catMarcas (depende de SUBRAMO)
        for index, apartado in cat_apartados.iterrows():
            subramo = str(apartado['SUBRAMO']).zfill(2)  # Extraer el valor de SUBRAMO desde cat_apartados

            for _, row in input_file.iterrows():
                # Construir valores para el `INSERT` en catMarcas
                values_cat_marcas = (
                    f"'00'",  # GpoMarcas siempre es '00'
                    f"'{row['DESCMARCA']}'",  # Descripcion
                    f"'70'",  # CveRamo siempre es '70'
                    f"'{subramo}'",  # CveSubRamo desde cat_apartados
                    f"'{row['CODMARCA_CORTA']}'",  # CveMarca desde input_file
                    f"'{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}'"  # FechaRegistro
                )

                sql_query_cat_marcas = f"""
                INSERT INTO /shared/CONEXIONES/SAFE_SARAWEB/Saraweb/dbo/catMarcas
                (GpoMarcas, Descripcion, CveRamo, CveSubRamo, CveMarca, FechaUltimaModificacion)
                VALUES ({','.join(values_cat_marcas)});
                """

                # Ejecutar el `INSERT` de manera individual
                result_cat_marcas = self.tdv.execute_insert(sql_query_cat_marcas)

                if result_cat_marcas:
                    insert_scripts_catMarcas.append(sql_query_cat_marcas)
                else:
                    fails.append(sql_query_cat_marcas)

        # Insertar en tmarca_especial (no depende de SUBRAMO)
        for _, row in input_file.iterrows():
            # Construir valores para el `INSERT` en tmarca_especial
            values_tmarca_especial = (
                f"'{row['CODMARCA_CORTA']}'",  # CveMarca desde input_file
                f"'0'",
                f"'0'",
            )

            sql_query_tmarca_especial = f"""
            INSERT INTO /shared/CONEXIONES/SAFE_SARAWEB/Saraweb/dbo/tmarca_especial
            (cve_marca, normalEspecial, OpcionVision)
            VALUES ({','.join(values_tmarca_especial)});
            """

            # Ejecutar el `INSERT` de manera individual
            result_tmarca_especial = self.tdv.execute_insert(sql_query_tmarca_especial)

            if result_tmarca_especial:
                insert_scripts_tmarca_especial.append(sql_query_tmarca_especial)
            else:
                fails.append(sql_query_tmarca_especial)

        # Guardar resultados exitosos de catMarcas
        if insert_scripts_catMarcas:
            df_inserts_cat_marcas = aws_conn.traer_dataframe_desde_s3(s3_key_inserts, s3_bucket_name)
            new_inserts_cat_marcas = pd.DataFrame({"script": insert_scripts_catMarcas})
            df_inserts_cat_marcas = pd.concat([df_inserts_cat_marcas, new_inserts_cat_marcas], ignore_index=True) if df_inserts_cat_marcas is not None else new_inserts_cat_marcas
            aws_conn.guardar_dataframe_vista_en_s3(df_inserts_cat_marcas, s3_key_inserts, s3_bucket_name)

        # Guardar resultados exitosos de tmarca_especial
        s3_key_inserts_tmarca_especial = 'tmarca_especial_inserts.txt'
        if insert_scripts_tmarca_especial:
            df_inserts_tmarca_especial = aws_conn.traer_dataframe_desde_s3(s3_key_inserts_tmarca_especial, s3_bucket_name)
            new_inserts_tmarca_especial = pd.DataFrame({"script": insert_scripts_tmarca_especial})
            df_inserts_tmarca_especial = pd.concat([df_inserts_tmarca_especial, new_inserts_tmarca_especial], ignore_index=True) if df_inserts_tmarca_especial is not None else new_inserts_tmarca_especial
            aws_conn.guardar_dataframe_vista_en_s3(df_inserts_tmarca_especial, s3_key_inserts_tmarca_especial, s3_bucket_name)

        # Guardar fallos
        if fails:
            print("Error ejecutando algunos INSERTs para marcas.")
            df_fails = aws_conn.traer_dataframe_desde_s3(s3_key_inserts_fails, s3_bucket_name)
            new_fails = pd.DataFrame({"script": fails})
            df_fails = pd.concat([df_fails, new_fails], ignore_index=True) if df_fails is not None else new_fails
            aws_conn.guardar_dataframe_vista_en_s3(df_fails, s3_key_inserts_fails, s3_bucket_name)

    
    def concatenar_columnas_dataframe(self,df,columnas_concat,nombre_campo):
        df[nombre_campo] = ''
        try:
            # Crear una nueva columna en el DataFrame df concatenando las columnas especificadas en la columna especificada    
            for col in columnas_concat:
                df[nombre_campo] += df[col].astype(str)
            print("Se concateno la columna {}".format(nombre_campo))
            return df
        except:
            print("No se pudo concatenar")
            return df
    
    def verificar_llave_success_en_vista(self,df_vista):
        columnas_concat = ['CODCAT','CODAPARTADO','CODVEHICULO']
        # Crear una nueva columna ID concatenando las columnas especificadas
        df_vista = self.concatenar_columnas_dataframe(df_vista,columnas_concat,'ID')
        df_succ = self.concatenar_columnas_dataframe(self.input_file,columnas_concat,'ID')

        # Comprobar si los registros del archivo success existen en la vista
        df_succ['existe'] = df_succ['ID'].isin(df_vista['ID'])
    
        # Separar registros del archivo success entre los que existen o no en la vista
        df_true = df_succ[df_succ['existe'] == True]
        df_false = df_succ[df_succ['existe'] == False]
        return df_true, df_false
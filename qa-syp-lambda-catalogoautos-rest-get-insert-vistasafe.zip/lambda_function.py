from TDV import TDV
from CAT import Catalogo
from EBX import EBX
import pandas as pd
from AWS import AWS
import os
import pprint
import json

def lambda_handler(event, context):
    try:
        # Se obtiene objeto de conexión a EBX
        ruta_modelo_datos = os.getenv("ruta_modelo_datos")
        ebx = EBX(ruta_modelo_datos)
        
        # Se obtiene objeto de conexión a AWS
        s3_bucket_name = os.getenv("s3_bucket_name")
        aws_conn = AWS()

        # Se extraen las tablas de EBX y se depositan en S3
        apartado_veh = ebx.select_tabla_content('CAT_APARTADOS')
        aws_conn.guardar_dataframe_vista_en_s3(apartado_veh, 'CAT_APARTADOS.csv', s3_bucket_name)

        # Se extrae la vista SAFE de la tabla ENTIDAD_VEHICULO y se deposita en S3
        vista_safe = ebx.select_vista_content('ENTIDAD_VEHICULO', 'ENTIDAD_SAFE')
        aws_conn.guardar_dataframe_vista_en_s3(vista_safe, 'VISTA_SAFE_ENTIDAD_VEHICULO.csv', s3_bucket_name)
        vista_safe_file = 'vista-safe/VISTA_SAFE_ENTIDAD_VEHICULO.csv'

        try:
            df_vista = aws_conn.traer_dataframe_desde_s3(vista_safe_file, s3_bucket_name)
        except Exception as e:
            print(f"Error al cargar el archivo {vista_safe_file}: {str(e)}")
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'mensaje': f'Error al cargar el archivo {vista_safe_file}',
                    'error': str(e)
                })
            }

        # Conexión a TDV
        url = os.getenv("url_tdv")
        user = os.getenv("usuario")
        domain = os.getenv("dominio")
        user = user + '@' + domain
        password = aws_conn.get_secret()
        tdv = TDV(url, user, password)

        # Procesar los archivos de autos (Insert y Update)
        archivos_autos = [
            'carga-continua/entidad-insert/Succes_Entidades_Insert.csv',
            'carga-continua/entidad-update/Succes_Entidades_Update.csv'
        ]
        for archivo in archivos_autos:
            try:
                entidades_success = aws_conn.traer_dataframe_desde_s3(archivo, s3_bucket_name)
                autos = Catalogo('autos', entidades_success, tdv)
                autos.insertar_autos(df_vista)
            except Exception as e:
                print(f"Error al cargar o procesar el archivo {archivo}: {str(e)}")
                continue  # Saltar al siguiente archivo si hay un error

        # Procesar los archivos de modelos (Insert y Update)
        archivos_modelos = [
            'carga-continua/tarifas-insert/Succes_Tarifa_Insert.csv',
            'carga-continua/tarifas-update/Succes_Tarifa_Update.csv'
        ]
        for archivo in archivos_modelos:
            try:
                entidades_modelos = aws_conn.traer_dataframe_desde_s3(archivo, s3_bucket_name)
                modelos = Catalogo('modelos', entidades_modelos, tdv)
                modelos.insertar_modelos(df_vista)
            except Exception as e:
                print(f"Error al cargar o procesar el archivo {archivo}: {str(e)}")
                continue  # Saltar al siguiente archivo si hay un error

        # Procesar los archivos de tipos_veh (Insert y Update)
        archivos_tipos_veh = [
            'carga-continua/marcas-modelos/Succes_Modelos_Insert.csv',
            'carga-continua/marcas-modelos/Succes_Modelos_Update.csv'
        ]
        for archivo in archivos_tipos_veh:
            try:
                entidades_tipos_veh = aws_conn.traer_dataframe_desde_s3(archivo, s3_bucket_name)
                tipos_veh = Catalogo('tipo_veh', entidades_tipos_veh, tdv)
                tipos_veh.insertar_tipos_vehiculos()
            except Exception as e:
                print(f"Error al cargar o procesar el archivo {archivo}: {str(e)}")
                continue  # Saltar al siguiente archivo si hay un error

        # Procesar los archivos de marcas (Insert y Update)
        archivos_marcas = [
            'carga-continua/marcas-modelos/Succes_Marcas_Insert.csv',
            'carga-continua/marcas-modelos/Succes_Marcas_Update.csv'
        ]
        for archivo in archivos_marcas:
            try:
                entidades_marcas = aws_conn.traer_dataframe_desde_s3(archivo, s3_bucket_name)
                marcas = Catalogo('marcas', entidades_marcas, tdv)
                marcas.insertar_marcas()
            except Exception as e:
                print(f"Error al cargar o procesar el archivo {archivo}: {str(e)}")
                continue  # Saltar al siguiente archivo si hay un error

    except Exception as e:
        print(f"Error durante el proceso: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'mensaje': 'Error durante el proceso.',
                'error': str(e)
            })
        }
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'mensaje': 'Proceso completado exitosamente.'
        })
    }

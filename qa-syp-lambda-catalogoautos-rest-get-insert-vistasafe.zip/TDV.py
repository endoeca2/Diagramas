import requests
from xml.etree import ElementTree as ET
import os
import boto3
from io import StringIO
import json
from datetime import datetime, timezone, timedelta
import time
import pandas as pd

class TDV:
    def __init__(self, url=None, username=None, password=None):
        self.url = url or os.getenv("url_tdv")
        self.username = username or os.getenv("usuario")
        self.password = password or self.get_secret()
        self.s3_bucket_name = os.getenv("s3_bucket_name")
        self.secrets_client = boto3.client('secretsmanager')
        self.token = None
        self.token_url = f"http://{url}:9400/rest/auth/v1"
        self.token_valid_minutes = int(os.getenv("tiempo_token_ebx", 15))
        self.secret_id_tdv = os.getenv("secret_id_tdv")

        self.ns = {
            'resource': 'http://www.compositesw.com/services/system/admin/resource',
            'soap-env': 'http://schemas.xmlsoap.org/soap/envelope/',
            'common': 'http://www.compositesw.com/services/system/util/common',
            'execute': 'http://www.compositesw.com/services/system/admin/execute'
        }

    def get_token(self):
        control_key = "api/catalogo-autos/tdv-token-control.txt"
        s3 = boto3.client('s3')

        try:
            # Verificar si el token ya está en Secrets Manager y es reciente
            token_data = self.retrieve_token_from_secrets()
            if token_data and 'last_updated' in token_data:
                last_updated = datetime.fromisoformat(token_data['last_updated']).replace(tzinfo=timezone.utc)
                now = datetime.now(timezone.utc)
                if now - last_updated < timedelta(minutes=self.token_valid_minutes):
                    print("Token vigente encontrado, regresando accessToken.")
                    return True, token_data['accessToken']

            # Esperar si otra Lambda está solicitando un nuevo token
            s3 = boto3.client('s3')
            backoff = 1
            max_backoff = 16
            total_wait_time = 0

            while True:
                try:
                    s3.head_object(Bucket=self.s3_bucket_name, Key=control_key)
                    print("Esperando a que otra Lambda termine de solicitar un nuevo token...")
                    time.sleep(backoff)
                    total_wait_time += backoff
                    backoff = min(backoff * 2, max_backoff)

                    if total_wait_time >= 60:
                        raise TimeoutError("Timeout mientras se esperaba un nuevo token.")
                except s3.exceptions.ClientError:
                    break

            # Colocar el archivo de control para indicar que se está solicitando un nuevo token
            s3.put_object(Bucket=self.s3_bucket_name, Key=control_key, Body="En progreso")

            # Solicitar un nuevo token
            new_token = self.request_new_token()
            if new_token:
                self.store_token_in_secrets(new_token)
                print("Nuevo token obtenido y almacenado.")
                
                # Eliminar archivo de control y agregar una pausa
                s3.delete_object(Bucket=self.s3_bucket_name, Key=control_key)
                time.sleep(3)  # Pausa adicional para sincronización
                return True, new_token['accessToken']
            else:
                print("Error al obtener el token.")
                return False, None

        except Exception as e:
            # Asegurarse de que el archivo de control se elimine en caso de error
            try:
                s3.delete_object(Bucket=self.s3_bucket_name, Key=control_key)
            except Exception as cleanup_error:
                print("Error al limpiar el archivo de control del token:", cleanup_error)
            raise e

    # Método para solicitar un nuevo token desde TDV
    def request_new_token(self):
        data = {"appId": "Contrail"}
        headers = {"Content-Type": "application/json"}
        
        response = requests.post(self.token_url, json=data, auth=(self.username, self.password))
        if response.status_code in [200, 201]:
            try:
                response_data = json.loads(response.text)
                if isinstance(response_data, list) and len(response_data) > 0:
                    return json.loads(response_data[0])  # Convertir el string JSON del primer elemento en un dict
                else:
                    print("Formato inesperado en la respuesta del token.")
                    return None
            except json.JSONDecodeError as e:
                print("Error al procesar la respuesta del token:", e)
                return None
        else:
            print("Error al obtener el token", response.status_code, response.text)
            return None

    # Método para almacenar el token en Secrets Manager con 'last_updated'
    def store_token_in_secrets(self, token_data):
        # Añadimos la fecha de actualización al token
        token_data['last_updated'] = datetime.now().isoformat()
        # Convertimos el token a JSON y lo guardamos en Secrets Manager
        self.secrets_client.put_secret_value(
            SecretId=self.secret_id_tdv,
            SecretString=json.dumps(token_data)
        )

    # Método para recuperar el token de Secrets Manager
    def retrieve_token_from_secrets(self):
        try:
            # Recupera el secreto de Secrets Manager
            secret = self.secrets_client.get_secret_value(SecretId=self.secret_id_tdv)
            # Convierte el contenido JSON a un diccionario Python
            return json.loads(secret['SecretString'])
        except self.secrets_client.exceptions.ResourceNotFoundException:
            print("El token no se ha encontrado en Secrets Manager.")
            return None

    def getColumns(self, path, first_time:bool = True):
        resource_path = path

        # Define the SOAP endpoint and the SOAP envelope
        url = 'http://'+self.url+':9400/services/system/admin/resource/resourcePort.ws'
        headers = {
            'Content-Type': 'text/xml',
            'SOAPAction': 'getResource'
        }

        xml_body = """
        <Envelope xmlns="http://schemas.xmlsoap.org/soap/envelope/">
            <Body>
                <getResource xmlns="http://www.compositesw.com/services/system/admin/resource">
                    <path>{resource}</path>
                    <type>TABLE</type>
                    <detail>FULL</detail>
                </getResource>
            </Body>
        </Envelope>
        """
        xml_body = xml_body.format(resource = resource_path)
         # Specify your basic authentication credentials
        username = self.username
        password = self.password

        # Send the SOAP request with basic authentication
        response = requests.post(url, data=xml_body, headers=headers, auth=(username, password))

        # Check the response
        if response.status_code == 200:
            # Parse the SOAP response
            root = ET.fromstring(response.content)
            
            cols = []
            
            ns = {'resource': 'http://www.compositesw.com/services/system/admin/resource',
            'soap-env': 'http://schemas.xmlsoap.org/soap/envelope/',
            'common': 'http://www.compositesw.com/services/system/util/common'}

            columns = root.find('''.//resource:getResourceResponse/resource:resources/resource:resource/resource:columns''',ns)
            for col in columns:
                name = col.find('./resource:name',ns)
                cols.append(name.text)

            return cols

        else:
            if response.status_code == 401 and first_time:
                print('Retrying...')
                return self.getColumns(path, False)
            print(f"SOAP Request Failed. Status Code: {response.status_code}")
            print(response.text)

    def getNatives(self, path:str, view_cols, first_time:bool = True):
        resource_path = path

        # Define the SOAP endpoint and the SOAP envelope
        url = 'http://'+self.url+':9400/services/system/admin/resource/resourcePort.ws'
        headers = {
            'Content-Type': 'text/xml',
            'SOAPAction': 'getResource'
        }

        xml_body = """
        <Envelope xmlns="http://schemas.xmlsoap.org/soap/envelope/">
            <Body>
                <getResource xmlns="http://www.compositesw.com/services/system/admin/resource">
                    <path>{resource}</path>
                    <type>TABLE</type>
                    <detail>FULL</detail>
                </getResource>
            </Body>
        </Envelope>
        """
        xml_body = xml_body.format(resource = resource_path)
         # Specify your basic authentication credentials
        username = self.username
        password = self.password

        # Send the SOAP request with basic authentication
        response = requests.post(url, data=xml_body, headers=headers, auth=(username, password))
        # Check the response
        if response.status_code == 200:
            # Parse the SOAP response
            root = ET.fromstring(response.content)
            
            cols = {}
            
            ns = {'resource': 'http://www.compositesw.com/services/system/admin/resource',
            'soap-env': 'http://schemas.xmlsoap.org/soap/envelope/',
            'common': 'http://www.compositesw.com/services/system/util/common'}

            columns = root.find('''.//resource:getResourceResponse/resource:resources/resource:resource/resource:columns''',ns)
            for col in columns:
                name = col.find('./resource:name',ns)
                sqlType = col.find('./resource:dataType/common:sqlType/common:nativeType',ns)
                if name.text in view_cols:
                    cols.update({name.text:sqlType.text})
                # print(name.text)
            return cols

        else:
            if response.status_code == 401 and first_time:
                print('Retrying...')
                return self.getNatives(path, view_cols, False)
            print(f"SOAP Request Failed. Status Code: {response.status_code}")
            print(response.text)

    def getFolder(self, path:str, first_time:bool = True):
        resource_path = path

        # Define the SOAP endpoint and the SOAP envelope
        url = 'http://'+self.url+':9400/services/system/admin/resource/resourcePort.ws'
        headers = {
            'Content-Type': 'text/xml',
            'SOAPAction': 'getChildResources'
        }

        xml_body = """
        <Envelope xmlns="http://schemas.xmlsoap.org/soap/envelope/">
            <Body>
                <getChildResources xmlns="http://www.compositesw.com/services/system/admin/resource">
                    <path>{resource}</path>
                    <type>CONTAINER</type>
                    <detail>SIMPLE</detail>
                </getChildResources>
            </Body>
        </Envelope>
        """
        xml_body = xml_body.format(resource = resource_path)
         # Specify your basic authentication credentials
        username = self.username
        password = self.password

        # Send the SOAP request with basic authentication
        response = requests.post(url, data=xml_body, headers=headers, auth=(username, password))

        # Check the response
        if response.status_code == 200:
            # Parse the SOAP response
            root = ET.fromstring(response.content)
            
            views = []
            
            ns = {'resource': 'http://www.compositesw.com/services/system/admin/resource',
            'soap-env': 'http://schemas.xmlsoap.org/soap/envelope/',
            'common': 'http://www.compositesw.com/services/system/util/common'}

            columns = root.find('''.//resource:getChildResourcesResponse/resource:resources''',ns)
            for col in columns:
                path = col.find('./resource:path',ns)
                res_type = col.find('./resource:type',ns)
                if res_type.text == 'TABLE':
                    views.append(path.text)
                # print(name.text)
            return views

        else:
            if response.status_code == 401 and first_time:
                print('Retrying...')
                return self.getFolder(path, False)
            print(f"SOAP Request Failed. Status Code: {response.status_code}")
            print(response.text)

    def getScript(self, path, first_time:bool = True):
        resource_path = path

        # Define the SOAP endpoint and the SOAP envelope
        url = 'http://'+self.url+':9400/services/system/admin/resource/resourcePort.ws'
        headers = {
            'Content-Type': 'text/xml',
            'SOAPAction': 'getResource'
        }

        xml_body = """
        <Envelope xmlns="http://schemas.xmlsoap.org/soap/envelope/">
            <Body>
                <getResource xmlns="http://www.compositesw.com/services/system/admin/resource">
                    <path>{resource}</path>
                    <type>TABLE</type>
                    <detail>FULL</detail>
                </getResource>
            </Body>
        </Envelope>
        """
        xml_body = xml_body.format(resource = resource_path)
         # Specify your basic authentication credentials
        username = self.username
        password = self.password

        # Send the SOAP request with basic authentication
        response = requests.post(url, data=xml_body, headers=headers, auth=(username, password))

        # Check the response
        if response.status_code == 200:
            # Parse the SOAP response
            root = ET.fromstring(response.content)

            ns = {'resource': 'http://www.compositesw.com/services/system/admin/resource',
            'soap-env': 'http://schemas.xmlsoap.org/soap/envelope/',
            'common': 'http://www.compositesw.com/services/system/util/common'}

            script = root.find('''.//resource:getResourceResponse/resource:resources/resource:resource/resource:sqlText''',ns)
            #print(script.text)
            return script.text

        else:
            if response.status_code == 401 and first_time:
                print('Retrying...')
                return self.getScript(path, False)
            print(f"SOAP Request Failed. Status Code: {response.status_code}")
            print(response.text)

    def executeSqlScript(self, script:str, first_time:bool = True):

        # Define the SOAP endpoint and the SOAP envelope
        url = 'http://'+self.url+':9400/services/system/admin/execute/executePort.ws'
        headers = {
            'Content-Type': 'text/xml',
            'SOAPAction': 'executeSqlScript'
        }

        xml_body = """
        <Envelope xmlns="http://schemas.xmlsoap.org/soap/envelope/">
            <Body>
                <executeSqlScript xmlns="http://www.compositesw.com/services/system/admin/execute">
                    <scriptText>{sql_script}</scriptText>
                    <groups/>
                </executeSqlScript>
            </Body>
        </Envelope>
        """
        xml_body = xml_body.format(sql_script = script)
         # Specify your basic authentication credentials
        username = self.username
        password = self.password

        # Send the SOAP request with basic authentication
        response = requests.post(url, data=xml_body, headers=headers, auth=(username, password))

        # Check the response
        if response.status_code == 200:
            print(response.text)

        else:
            if response.status_code == 401 and first_time:
                print('Retrying...')
                self.getScript(script, False)
            print(f"SOAP Request Failed. Status Code: {response.status_code}")
            print(response.text)

    def executeSql(self, script:str, get_value=False, first_time:bool = True):

        # Define the SOAP endpoint and the SOAP envelope
        url = 'http://'+self.url+':9400/services/system/admin/execute/executePort.ws'
        headers = {
            'Content-Type': 'text/xml',
            'SOAPAction': 'executeSql'
        }        

        xml_body = """
        <Envelope xmlns="http://schemas.xmlsoap.org/soap/envelope/">
            <Body>
                <executeSql xmlns="http://www.compositesw.com/services/system/admin/execute">
                    <sqlText>{sql_script}</sqlText>
                    <includeMetadata>0</includeMetadata>
                </executeSql>
            </Body>
        </Envelope>
        """
        xml_body = xml_body.format(sql_script = script)
         # Specify your basic authentication credentials
        username = self.username
        password = self.password

        # Send the SOAP request with basic authentication
        response = requests.post(url, data=xml_body, headers=headers, auth=(username, password))

        # Check the response
        if response.status_code == 200:
            if get_value:
                # Parse the SOAP response
                root = ET.fromstring(response.content)

                ns = {'execute': 'http://www.compositesw.com/services/system/admin/execute',
                'soap-env': 'http://schemas.xmlsoap.org/soap/envelope/',
                'common': 'http://www.compositesw.com/services/system/util/common'}

                script = root.find('''.//execute:executeSqlResponse/execute:result/execute:rows/execute:row/execute:value''',ns)
                #print(script.text)
                return script.text
            else:
                print(response.text)

        else:
            if response.status_code == 401 and first_time:
                print('Retrying...')
                self.getScript(script, False)
            print(f"SOAP Request Failed. Status Code: {response.status_code}")
            print(response.text)

    def updateScript(self, path, sql_body):
        # Define the SOAP endpoint and the SOAP envelope
        url = 'http://{url}:9400/services/system/admin/resource/resourcePort.ws'.format(url = self.url)
        headers = {
            'Content-Type': 'text/xml; charset="utf-8"',
            'SOAPAction': 'updateSqlTable'
        }

        xml_body = """
        <Envelope xmlns="http://schemas.xmlsoap.org/soap/envelope/">
            <Body>
                <updateSqlTable xmlns="http://www.compositesw.com/services/system/admin/resource">
                    <path>{resource}</path>
                    <detail>FULL</detail>
                    <sqlText>{sql}</sqlText>
                </updateSqlTable>
            </Body>
        </Envelope>
        """
        xml_body = xml_body.format(resource = path,
                                    sql=sql_body)

        # Specify your basic authentication credentials
        username = self.username
        password = self.password

        # Send the SOAP request with basic authentication
        response = requests.post(url, data=xml_body, headers=headers, auth=(username, password))

        # Check the response
        if response.status_code == 200:
            print(response.text)
        else:
            print(f"SOAP Request Failed. Status Code: {response.status_code}")
            print(response.text)

    def executeResource(self, path:str, parameters=None, first_time:bool = True):

        # Define the SOAP endpoint and the SOAP envelope
        url = 'http://'+self.url+':9400/services/system/admin/execute/executePort.ws'
        headers = {
            'Content-Type': 'text/xml',
            'SOAPAction': 'executeProcedure'
        }

        parameters_string=''
        if parameters:
            params = ''
            for param in parameters:
                params = params + '''<parameter>
                                        <definition>{definition}</definition>
                                        <value>{val}</value>
                                     </parameter>\n'''.format(definition = param[0], val = param[1])
            parameters_string='''<inputs>\n\t{proc}\n\t</inputs>'''.format(proc = params)

        xml_body = """
        <Envelope xmlns="http://schemas.xmlsoap.org/soap/envelope/">
            <Body>
                <executeProcedure xmlns="http://www.compositesw.com/services/system/admin/execute">
                    {proc}
                    <path>{res_path}</path>
                    <type>PROCEDURE</type>
                </executeProcedure>
            </Body>
        </Envelope>
        """

        xml_body = xml_body.format(res_path = path, proc = parameters_string)
         # Specify your basic authentication credentials
        username = self.username
        password = self.password
        # Send the SOAP request with basic authentication
        response = requests.post(url, data=xml_body, headers=headers, auth=(username, password))

        #print(xml_body)

        # Check the response
        if response.status_code == 200:
            root = ET.fromstring(response.text)
            ns = {'execute': 'http://www.compositesw.com/services/system/admin/execute',
            'soap-env': 'http://schemas.xmlsoap.org/soap/envelope/',
            'common': 'http://www.compositesw.com/services/system/util/common'}

            script = root.find('''.//execute:executeProcedureResponse/execute:outputs/execute:value''',ns)
            print(response.text)
            return script.text

        else:
            if response.status_code == 401 and first_time:
                print('Retrying...')
                self.executeResource(path, parameters, False)
            print(f"SOAP Request Failed. Status Code: {response.status_code}")
            print(response.text)

    def refreshCache(self, path):
        resource_path = path

        # Define the SOAP endpoint and the SOAP envelope
        url = 'http://{resource_host}:9400/services/system/admin/resource/resourcePort.ws'.format(resource_host = self.url)
        headers = {
            'Content-Type': 'text/xml',
            'SOAPAction': 'refreshResourceCache'
        }

        xml_body = """
        <Envelope xmlns="http://schemas.xmlsoap.org/soap/envelope/">
            <Body>
                <refreshResourceCache xmlns="http://www.compositesw.com/services/system/admin/resource">
                    <path>{resource}</path>
                    <type>TABLE</type>
                </refreshResourceCache>
            </Body>
        </Envelope>
        """
        xml_body = xml_body.format(resource = resource_path)
         # Specify your basic authentication credentials
        username = self.username
        password = self.password

        # Send the SOAP request with basic authentication
        response = requests.post(url, data=xml_body, headers=headers, auth=(username, password))

        print(path)
        # Check the response
        if response.status_code == 200:
            # Parse the SOAP response
            print(response.text)
        else:
            print(f"SOAP Request Failed. Status Code: {response.status_code}")
            print(response.text)

    def cacheSwitch(self, path:str, enabled:bool):
        resource_path = path
        enable = 'false'
        if enabled:
            enable = 'true'
        # Define the SOAP endpoint and the SOAP envelope
        url = 'http://{resource_host}:9400/services/system/admin/resource/resourcePort.ws'.format(resource_host = self.url)
        headers = {
            'Content-Type': 'text/xml',
            'SOAPAction': 'updateResourceCacheConfig'
        }

        xml_body = """
        <Envelope xmlns="http://schemas.xmlsoap.org/soap/envelope/">
            <Body>
                <updateResourceCacheConfig xmlns="http://www.compositesw.com/services/system/admin/resource">
                    <path>{resource}</path>
                    <type>TABLE</type>
                    <detail>FULL</detail>
                    <cacheConfig>
                        <enabled>{cache_enable}</enabled>
                    </cacheConfig>
                </updateResourceCacheConfig>
            </Body>
        </Envelope>
        """
        xml_body = xml_body.format(resource = resource_path, cache_enable = enable)
         # Specify your basic authentication credentials
        username = self.username
        password = self.password

        # Send the SOAP request with basic authentication
        response = requests.post(url, data=xml_body, headers=headers, auth=(username, password))

        # Check the response
        if response.status_code == 200:
            # Parse the SOAP response

            print(response.text)
        else:
            print(f"SOAP Request Failed. Status Code: {response.status_code}")
            print(response.text)

    def execute_procedure(self, procedure_name, parameters=None):
        """
        Ejecuta un procedimiento almacenado en TDV mediante la API REST.
        
        Args:
            procedure_name (str): Nombre del procedimiento almacenado (SP) a ejecutar.
            parameters (dict): Diccionario con los parámetros del procedimiento.
                               Ejemplo: {"@param1": "value1", "@param2": "value2"}
        
        Returns:
            dict: Respuesta del servidor si la ejecución es exitosa.
            None: Si ocurre un error.
        """

        headers = {
            "accept": "application/json"
        }
        # Construir la URL del endpoint con el nombre del procedimiento
        endpoint = f"http://{self.url}:9400/json/SAFE/{procedure_name}"

        # Mostrar la URL y los parámetros para depuración
        print("Request URL:", endpoint)
        print("Request Parameters:", parameters)

        try:
            # Realizar la solicitud con autenticación básica
            response = requests.post(endpoint, params=parameters, headers=headers, auth=(self.username, self.password))
            
            # Verificar el estado de la respuesta
            if response.status_code == 200:
                print("Procedimiento ejecutado exitosamente.")
                return response.json()
            elif response.status_code == 401:
                print("Autenticación inválida. Verifica tu usuario y contraseña.")
                return None
            else:
                print(f"Error al ejecutar el procedimiento {procedure_name}: {response.status_code}")
                print("Detalle:", response.text)
                return None
        except requests.exceptions.RequestException as e:
            print(f"Error al conectar con TDV: {e}")
            return None

    def execute_select(self, query):
        """
        Ejecuta un SELECT directamente en TDV mediante la API REST.
        
        Args:
            query (str): Consulta SQL a ejecutar.
        
        Returns:
            dict: Resultado del SELECT si tiene éxito.
            None: Si ocurre un error.
        """

        token_status, token = self.get_token()
        if not token_status:
            print("Error al obtener un token válido. No se puede ejecutar el procedimiento.")
            return None

        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}"
        }
        endpoint = f"http://{self.url}:9400/rest/execute/v1/actions/query/invoke"
        request_body = {
            "query": query,
            "standardSQL": False,
            "blocking": True
        }

        print("Request Body:", request_body) 

        try:
            response = requests.post(endpoint, headers=self.headers, json=request_body)
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 401:
                print("Token inválido o expirado.")
                return None
            else:
                print(f"Error al ejecutar la consulta: {response.status_code}")
                print("Detalle:", response.text)
                return None
        except requests.exceptions.RequestException as e:
            print(f"Error al conectar con TDV: {e}")
            return None

    def execute_insert(self, sql_query):
        """
        Ejecuta una sentencia SQL en TDV utilizando el endpoint REST.

        Args:
            sql_query (str): Sentencia SQL que se desea ejecutar.

        Returns:
            dict: Respuesta del servidor si la ejecución es exitosa.
            None: Si ocurre un error.
        """
        # Obtener un token válido utilizando get_token
        token_status, token = self.get_token()
        if not token_status:
            print("Error al obtener un token válido. No se puede ejecutar la consulta.")
            return None

        # Endpoint para ejecutar el script SQL
        endpoint = f"http://{self.url}:9400/rest/execute/v1/actions/sqlscript/invoke"

        # Procedimiento temporal que realiza la ejecución de la sentencia SQL
        procedural_query = f"""
        PROCEDURE TempProcedure()
        BEGIN
            {sql_query}
        END
        """

        # Payload para la solicitud
        data = {
            "blocking": True,
            "includeMetadata": False,
            "parameterBeanList": [],
            "scriptText": procedural_query
        }

        # Headers para autenticación
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

        try:
            # Realizar la solicitud POST al endpoint
            response = requests.post(endpoint, headers=headers, json=data)

            # Evaluar la respuesta
            if response.status_code == 200:
                print(f"SQL ejecutado exitosamente: {sql_query}")
                return response.json()
            elif response.status_code == 401:
                print("Token inválido o expirado. Intentando obtener un nuevo token...")
                # Intentar renovar el token y reintentar la consulta
                self.token = None  # Invalidate the current token
                return self.execute_insert(sql_query)  # Reintentar la ejecución
            else:
                print(f"Error al ejecutar SQL: {sql_query}")
                print(f"Status Code: {response.status_code}")
                print(f"Response Text: {response.text}")
                return None
        except requests.exceptions.RequestException as e:
            print(f"Error al conectarse al endpoint TDV: {e}")
            return None